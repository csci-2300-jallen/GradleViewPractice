package org.example.view;

import java.util.Scanner;
import org.example.WordGuessingGame;

public class Terminal implements View {
    private final Scanner input = new Scanner(System.in);
    private boolean running = true;
    private WordGuessingGame game;

    @Override
    public void setGame(WordGuessingGame game) {
        this.game = game;
    }

    @Override
    public void startInput() {
        while (running) {
            System.out.print("Your guess: ");
            if (!input.hasNextLine()) {
                return;
            }
            game.guess(input.nextLine());
        }
    }

    @Override
    public void showWord(String word) {
        System.out.println(word);
    }

    @Override
    public void showMessage(String message) {
        System.out.println(message);
    }

    @Override
    public void endGame() {
        running = false;
    }
}
