package org.example.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.example.WordGuessingGame;

public class GUI implements View {
    private JFrame frame;
    private JLabel wordLabel;
    private JLabel messageLabel;
    private final JButton[] buttons = new JButton[26];

    @Override
    public void setGame(WordGuessingGame game) {
        frame = new JFrame("Word Guessing Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(2, 1));

        wordLabel = new JLabel(" ", JLabel.CENTER);
        messageLabel = new JLabel(" ", JLabel.CENTER);
        JPanel feedback = new JPanel(new GridLayout(2, 1));
        feedback.add(wordLabel);
        feedback.add(messageLabel);

        JPanel letters = new JPanel(new GridLayout(2, 13));
        for (int i = 0; i < buttons.length; i++) {
            char letter = (char) ('A' + i);
            JButton button = new JButton("" + letter);
            button.addActionListener(event -> game.guess(button.getText()));
            buttons[i] = button;
            letters.add(button);
        }

        frame.add(feedback);
        frame.add(letters);
        frame.setSize(750, 200);
        frame.setLocationRelativeTo(null);
    }

    @Override
    public void startInput() {
        frame.setVisible(true);
    }

    @Override
    public void showWord(String word) {
        wordLabel.setText(word);
    }

    @Override
    public void showMessage(String message) {
        messageLabel.setText(message);
    }

    @Override
    public void endGame() {
        for (JButton button : buttons) {
            button.setEnabled(false);
        }
    }
}
