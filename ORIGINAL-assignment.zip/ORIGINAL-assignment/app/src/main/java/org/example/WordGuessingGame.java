package org.example;

import org.example.view.*;

public class WordGuessingGame {
    private final View view;
    private final String word = "APPLE";
    private final char[] currentWord = "-----".toCharArray();
    private int misses = 0;

    public WordGuessingGame(View view) {
        this.view = view;
    }

    public static void main(String[] args) {
        View view = new GUI(); // Change to new GUI() for Swing.
        WordGuessingGame game = new WordGuessingGame(view);
        game.start();
    }

    public void start() {
        view.setGame(this);
        view.showMessage("Guess one letter at a time. You lose after 5 misses.");
        showWord();
        view.startInput();
    }

    // Both views call this method when the player guesses a letter.
    public void guess(String guess) {
        char letter = guess.toUpperCase().charAt(0);

        if (word.indexOf(letter) >= 0) {
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == letter) {
                    currentWord[i] = letter;
                }
            }
            view.showMessage("Correct letter!");
        } else {
            misses++;
            view.showMessage("That letter is not in the word. Misses: " + misses + "/5");
        }
        showWord();

        if (word.equals(new String(currentWord))) {
            view.showMessage("You win! The word was " + word + ".");
            view.endGame();
        } else if (misses == 5) {
            view.showMessage("You lose! The word was " + word + ".");
            view.endGame();
        }
    }

    private void showWord() {
        String display = "";
        for (char letter : currentWord) {
            display += letter + " ";
        }
        view.showWord(display.trim());
    }
}
