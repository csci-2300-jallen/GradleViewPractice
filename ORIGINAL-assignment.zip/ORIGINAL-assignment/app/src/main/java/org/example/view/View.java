package org.example.view;

import org.example.WordGuessingGame;

public interface View {
    void setGame(WordGuessingGame game);
    void startInput();
    void showWord(String word);
    void showMessage(String message);
    void endGame();
}
